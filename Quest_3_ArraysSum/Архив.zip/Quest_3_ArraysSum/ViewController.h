//
//  ViewController.h
//  Quest_3_ArraysSum
//
//  Created by user on 08.11.16.
//  Copyright © 2016 Abdushev Sergey. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController


@end

