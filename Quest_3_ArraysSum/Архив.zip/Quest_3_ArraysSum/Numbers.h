//
//  Numbers.h
//  Quest_3_ArraysSum
//
//  Created by user on 08.11.16.
//  Copyright © 2016 Abdushev Sergey. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

@interface Numbers : NSObject

@property ( assign, nonatomic) CGFloat fVal;
@property (assign, nonatomic) NSInteger inVal;

@end
