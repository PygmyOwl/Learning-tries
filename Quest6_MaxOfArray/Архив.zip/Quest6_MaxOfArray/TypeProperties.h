//
//  TypeProperties.h
//  Quest6_MaxOfArray
//
//  Created by user on 11.11.16.
//  Copyright © 2016 Abdushev Sergey. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

@interface TypeProperties : NSObject

@property (assign, nonatomic) CGFloat fVal;
@property (assign, nonatomic) NSInteger intVal;

@end
