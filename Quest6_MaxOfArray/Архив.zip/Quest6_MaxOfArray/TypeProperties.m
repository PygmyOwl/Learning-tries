//
//  TypeProperties.m
//  Quest6_MaxOfArray
//
//  Created by user on 11.11.16.
//  Copyright © 2016 Abdushev Sergey. All rights reserved.
//

#import "TypeProperties.h"

@implementation TypeProperties

@end
