//
//  ViewController.h
//  Quest6_MaxOfArray
//
//  Created by user on 11.11.16.
//  Copyright © 2016 Abdushev Sergey. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController


@end

