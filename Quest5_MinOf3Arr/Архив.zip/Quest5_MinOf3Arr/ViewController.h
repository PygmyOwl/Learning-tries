//
//  ViewController.h
//  Quest5_MinOf3Arr
//
//  Created by user on 10.11.16.
//  Copyright © 2016 Abdushev Sergey. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController


@end

