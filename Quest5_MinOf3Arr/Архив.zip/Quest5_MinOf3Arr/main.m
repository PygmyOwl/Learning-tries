//
//  main.m
//  Quest5_MinOf3Arr
//
//  Created by user on 10.11.16.
//  Copyright © 2016 Abdushev Sergey. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
